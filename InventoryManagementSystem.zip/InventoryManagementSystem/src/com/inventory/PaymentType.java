package com.inventory;



public enum PaymentType { 
	credit,
	debit,
	cash;

 
 }