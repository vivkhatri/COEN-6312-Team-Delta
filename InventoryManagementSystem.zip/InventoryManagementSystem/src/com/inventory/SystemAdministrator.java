package com.inventory;



public class SystemAdministrator extends Employee {

	/**
	 * 
	 */
	public void createUser() { 
		// TODO Auto-generated method
	 }

	/**
	 * 
	 */
	public void deleteUser() { 
		// TODO Auto-generated method
	 }

	/**
	 * 
	 */
	public void updateUser() { 
		// TODO Auto-generated method
	 }

	/**
	 * 
	 */
	public void maintainLedger() { 
		// TODO Auto-generated method
	 }

	/**
	 * 
	 */
	public void qualityCheck() { 
		// TODO Auto-generated method
	 } 

}