package com.inventory;



public enum OrderStatus { 
	hold,
	delivered,
	open,
	close;

 
 }