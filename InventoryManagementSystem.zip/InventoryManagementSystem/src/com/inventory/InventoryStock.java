package com.inventory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class InventoryStock {

	InventoryStock inventory;

	/**
	 * 
	 */
	public int productId;
	/**
	 * 
	 */
	public String productDescription;
	/**
	 * 
	 */
	public int quantity;
	/**
	 * 
	 */
	public int base_price;
	/**
	 * 
	 */
	public UnitOfMeasure unitOfMeasure;
	/**
	 * 
	 */
	public Date dateOfExpiry;

	/**
	 * Getter of productId
	 */
	public int getProductId() {
		return productId;
	}

	/**
	 * Setter of productId
	 */
	public void setProductId(int productId) {
		this.productId = productId;
	}

	/**
	 * Getter of productDescription
	 */
	public String getProductDescription() {
		return productDescription;
	}

	/**
	 * Setter of productDescription
	 */
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	/**
	 * Getter of quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * Setter of quantity
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/**
	 * Getter of Product Base Price
	 */
	public int getBasePrice() {
		return base_price;
	}

	/**
	 * Setter of Product Base Price
	 */
	public void setBasePrice(int base_price) {
		this.base_price = base_price;
	}

	/**
	 * Getter of unitOfMeasure
	 */
	public UnitOfMeasure getUnitOfMeasure() {
		return unitOfMeasure;
	}

	/**
	 * Setter of unitOfMeasure
	 */
	public void setUnitOfMeasure(UnitOfMeasure unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	/**
	 * Getter of dateOfExpiry
	 */
	public Date getDateOfExpiry() {
		return dateOfExpiry;
	}

	/**
	 * Setter of dateOfExpiry
	 */
	public void setDateOfExpiry(Date dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}

	/**
	 * @throws ParseException
	 * 
	 */
	public void addStock() throws ParseException {
		// TODO Auto-generated method
		Scanner stock = new Scanner(System.in);

		System.out.println("Enter the Product Id:");
		int product_id = Integer.parseInt(stock.nextLine());

		System.out.println("Enter the Product Name:");
		String product_name = stock.nextLine();

		System.out.println("Enter the Qty");
		int product_qty = Integer.parseInt(stock.nextLine());

		System.out.println("Enter the Unit");
		String product_unit = stock.nextLine();
		UnitOfMeasure uom = UnitOfMeasure.valueOf(product_unit);

		System.out.println("Enter Product Base Price");
		int product_price = Integer.parseInt(stock.nextLine());

		System.out.println("Enter the Expiry Date");
		String expiry_date = stock.nextLine();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date product_date = (Date) dateFormat.parse(expiry_date);
		System.out.println("Date : " + product_date);

		if (product_id > 0 && product_qty > 0) {
			this.setProductId(product_id);
			this.setProductDescription(product_name);
			this.setQuantity(product_qty);
			this.setUnitOfMeasure(uom);
			this.setDateOfExpiry(product_date);
			this.setBasePrice(product_price);
		}

	}

	/**
	 * @throws ParseException
	 * 
	 */
	public void changeDetails() throws ParseException {
		// TODO Auto-generated method
		Scanner stock = new Scanner(System.in);
		if (inventory != null) {
			int product_id = inventory.getProductId();
			System.out.println("Product Id : " + inventory.getProductId());
			System.out.println("Product Description : " + inventory.getProductDescription());
			System.out.println("Enter the Qty");
			int product_qty = Integer.parseInt(stock.nextLine());

			int available_qty = inventory.getQuantity();
			int total_qty = available_qty + product_qty;
			System.out.println("Total Quantity : " + total_qty);
			System.out.println("Available Quantity : " + available_qty);
			System.out.println("product Quantity : " + product_qty);

			System.out.println("Enter the Unit");
			String product_unit = stock.nextLine();
			UnitOfMeasure uom = UnitOfMeasure.valueOf(product_unit);

			System.out.println("Enter Product Base Price");
			int product_price = Integer.parseInt(stock.nextLine());

			System.out.println("Enter the Expiry Date");
			String expiry_date = stock.nextLine();
			SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date product_date = (Date) dateFormat.parse(expiry_date);
			System.out.println("Date : " + product_date);

			if (product_id > 0) {

				inventory.setQuantity(total_qty);
				inventory.setUnitOfMeasure(uom);
				inventory.setBasePrice(product_price);
				inventory.setDateOfExpiry(product_date);
				System.out.println("Stock Updated Successfully");
				inventory.listStock();

			}

		}
	}

	/**
	 * 
	 */
	public void listStock() {
		System.out.println("Product Id : " + this.getProductId());
		System.out.println("Product Description : " + this.getProductDescription());
		System.out.println("Product Quantity : " + this.getQuantity());
		System.out.println("Product Unit Of Measure : " + this.getUnitOfMeasure());
		System.out.println("Product Base Price : " + this.getBasePrice());
		System.out.println("Product Date Of Expiry : " + this.getDateOfExpiry());
	}

}