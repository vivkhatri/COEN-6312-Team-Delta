package com.inventory;

import java.util.Date;

public class Credit extends Payment {

	/**
	 * 
	 */
	public String cardHolderName;
	/**
	 * 
	 */
	public int creditCardNo;
	/**
	 * 
	 */
	public Date expiryDate;
	/**
	 * 
	 */
	public int cvvNo;
	/**
	 * Getter of cardHolderName
	 */
	public String getCardHolderName() {
	 	 return cardHolderName; 
	}
	/**
	 * Setter of cardHolderName
	 */
	public void setCardHolderName(String cardHolderName) { 
		 this.cardHolderName = cardHolderName; 
	}
	/**
	 * Getter of creditCardNo
	 */
	public int getCreditCardNo() {
	 	 return creditCardNo; 
	}
	/**
	 * Setter of creditCardNo
	 */
	public void setCreditCardNo(int creditCardNo) { 
		 this.creditCardNo = creditCardNo; 
	}
	/**
	 * Getter of expiryDate
	 */
	public Date getExpiryDate() {
	 	 return expiryDate; 
	}
	/**
	 * Setter of expiryDate
	 */
	public void setExpiryDate(Date expiryDate) { 
		 this.expiryDate = expiryDate; 
	}
	/**
	 * Getter of cvvNo
	 */
	public int getCvvNo() {
	 	 return cvvNo; 
	}
	/**
	 * Setter of cvvNo
	 */
	public void setCvvNo(int cvvNo) { 
		 this.cvvNo = cvvNo; 
	}
	/**
	 * 
	 */
	public void cardValidation() { 
		// TODO Auto-generated method
	 } 

}