package com.inventory;


public enum DeliveryStatus { 
	pending,
	hold,
	open,
	close,
	expired;

 
 }