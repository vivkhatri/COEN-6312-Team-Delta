package com.inventory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Scanner;

public class SalesOrder {
	HashMap<Integer, SalesOrderItem> salesOrderItemMap = new HashMap<Integer, SalesOrderItem>();
	/**
	 * 
	 */
	public int orderNo;
	/**
	 * 
	 */
	public Date orderDate;
	/**
	 * 
	 */
	public int cust_id;
	/**
	 * 
	 */
	public int emp_id;
	/**
	 * 
	 */
	public Float orderAmount;
	/**
	 * 
	 */
	public String shipping_address;
	/**
	 * 
	 */
	public Date shipping_date;
	/**
	 * 
	 */
	public OrderStatus orderStatus;
	/**
	 * 
	 */
	public int noOfItems;

	/**
	 * Getter of orderNo
	 */
	public int getOrderNo() {
		return orderNo;
	}

	/**
	 * Setter of orderNo
	 */
	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}

	/**
	 * Getter of orderDate
	 */
	public Date getOrderDate() {
		return orderDate;
	}

	/**
	 * Setter of orderDate
	 */
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	/**
	 * Getter of cust_id
	 */
	public int getCust_id() {
		return cust_id;
	}

	/**
	 * Setter of cust_id
	 */
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

	/**
	 * Getter of emp_id
	 */
	public int getEmp_id() {
		return emp_id;
	}

	/**
	 * Setter of emp_id
	 */
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	/**
	 * Getter of orderAmount
	 */
	public Float getOrderAmount() {
		return orderAmount;
	}

	/**
	 * Setter of orderAmount
	 */
	public void setOrderAmount(Float orderAmount) {
		this.orderAmount = orderAmount;
	}

	/**
	 * Getter of shipping_address
	 */
	public String getShipping_address() {
		return shipping_address;
	}

	/**
	 * Setter of shipping_address
	 */
	public void setShipping_address(String shipping_address) {
		this.shipping_address = shipping_address;
	}

	/**
	 * Getter of shipping_date
	 */
	public Date getShipping_date() {
		return shipping_date;
	}

	/**
	 * Setter of shipping_date
	 */
	public void setShipping_date(Date shipping_date) {
		this.shipping_date = shipping_date;
	}

	/**
	 * Getter of orderStatus
	 */
	public OrderStatus getOrderStatus() {
		return orderStatus;
	}

	/**
	 * Setter of orderStatus
	 */
	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}

	/**
	 * Getter of noOfItems
	 */
	public int getNoOfItems() {
		return noOfItems;
	}

	/**
	 * Setter of noOfItems
	 */
	public void setNoOfItems(int noOfItems) {
		this.noOfItems = noOfItems;
	}

	/**
	 * 
	 */
	public void printOrder() {
		// TODO Auto-generated method
	}

	/**
	 * 
	 */
	public void calculateTax() {
		// TODO Auto-generated method
	}

	/**
	 * 
	 */
	public void totalAmount() {
		// TODO Auto-generated method
	}

	/**
	 * @throws ParseException
	 * 
	 */
	public void createOrder(Customer customer, HashMap<Integer, InventoryStock> inventoryMap) throws ParseException {
		Boolean saveOrderStatus = false;
		int total_orderQty = 0;
		float total_orderAmt = 0;
		SalesOrder saleOrder = new SalesOrder();
		Scanner salesOrder = new Scanner(System.in);
		System.out.println("Customer ID : " + customer.getCust_id());
		System.out.println("Customer Name : " + customer.getName());
		//saveOrderStatus = true;
		String Shipping_address = customer.getShipping_address();
		System.out.println("Enter the Shipping Date");
		String shipping_date1 = salesOrder.nextLine();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date shipping_date = (Date) dateFormat.parse(shipping_date1);
		System.out.println("Date : " + shipping_date);

		Random rand = new Random();
		int order = rand.nextInt(50) + 1;
		String product_name = null;
		int product_price = 0;
		UnitOfMeasure uom = null;
		System.out.println("Enter Number of line Item : ");
		int lineItem = Integer.parseInt(salesOrder.nextLine());

		
		while (lineItem != 0) {
			System.out.println("Enter the line Item No: ");
			int lineItemNo = Integer.parseInt(salesOrder.nextLine());
			
			System.out.println("Available Line Items");
			for (Map.Entry<Integer, InventoryStock> entry : inventoryMap.entrySet()) {
				System.out.println("Inventory List ID & Description: " + entry.getKey() +"  "+ entry.getValue().productDescription);
			}
			
			System.out.println("Enter Product Id: ");
			int product_id = Integer.parseInt(salesOrder.nextLine());
			InventoryStock inventory = inventoryMap.get(product_id);
			product_name = inventory.getProductDescription();
			System.out.println("Product Name : " + inventory.getProductDescription());

			System.out.println("Enter Order Quantity: ");
			int orderQuantity = Integer.parseInt(salesOrder.nextLine());

			int stockQuantity = inventory.getQuantity();
			if (orderQuantity <= stockQuantity) {
				saveOrderStatus = true;
				uom = inventory.getUnitOfMeasure();
				product_price = inventory.getBasePrice();
				stockQuantity = stockQuantity - orderQuantity;
				inventory.setQuantity(stockQuantity);
				total_orderQty = total_orderQty + orderQuantity;

			} else {
				saveOrderStatus = false;
				System.out.println("Ordered Quantity is more than Stock Quantity");
			}
			if (saveOrderStatus == true) {
				SalesOrderItem salesOrderItem = new SalesOrderItem();
				salesOrderItem.setOrderNo(orderNo);
				salesOrderItem.setOrderLineItemNo(lineItem);
				salesOrderItem.setProductId(product_id);
				salesOrderItem.setProductDescription(product_name);
				salesOrderItem.setQuantity(orderQuantity);
				salesOrderItem.setUnitMeasure(uom);
				float amount = orderQuantity * product_price;
				total_orderAmt = total_orderAmt + amount;
				salesOrderItem.setAmount(amount);
				
				Integer ItemNumber = lineItem;
				
				salesOrderItemMap.put(ItemNumber, salesOrderItem);
				for (Map.Entry<Integer, SalesOrderItem> entry : salesOrderItemMap.entrySet()) {
					System.out.println("Sales Order Line Item Details:: " + entry.getKey() +"   "+ entry.getValue().getProductDescription());
				}
				
				SalesOrderItem soi = new SalesOrderItem();
				soi = salesOrderItemMap.get(ItemNumber);
				System.out.println("Product_Id in Line Item : " + soi.getProductId());
				System.out.println("Product_Name in Line Item : " + soi.getProductDescription());
			}

			lineItem--;
		}
		
		this.setOrderNo(order);
		this.setCust_id(customer.getCust_id());
		this.setShipping_address(Shipping_address);
		this.setShipping_date(shipping_date);
		this.setNoOfItems(total_orderQty);
		total_orderAmt = (float)(total_orderAmt + ((total_orderAmt) * (0.15)));
		this.setOrderAmount(total_orderAmt);
		this.setOrderStatus(OrderStatus.open);
		System.out.println("Sales Order Created with orderNo : " + order);
		
	}

	/**
	 * 
	 */
	public void changeOrder() {
		// TODO Auto-generated method
	}

	/**
	 * 
	 */
	public void cancelOrder() {
		// TODO Auto-generated method
	}
	
	/**
	 * 
	 */
	public void viewOrder() {
		// TODO Auto-generated method
		
		System.out.println(" Sales Order Details : ");
		
		System.out.println("Sales Order No : " + this.getOrderNo());
		System.out.println("Sales Customer Id : " + this.getCust_id());
		System.out.println("Sales Total Amount : " + this.getOrderAmount());
		System.out.println("Sales Total No of Items : " + this.getNoOfItems());
		System.out.println("Sales Shipping Address : " + this.getShipping_address());
		System.out.println("Sales Shipping Date : " + this.getShipping_date());
		System.out.println("Sales Order Status : " + this.getOrderStatus());
		
		System.out.println(" Sales Order Line Item Details : ");
		for (Map.Entry<Integer, SalesOrderItem> entry : salesOrderItemMap.entrySet()) {
			System.out.println("Sales Order Line Item Product Id : " + entry.getKey());
			System.out.println("Sales Order Line Item Product Name : " + entry.getValue().getProductDescription());
			System.out.println("Sales Order Line Item Product Quantity : " + entry.getValue().getQuantity());
			System.out.println("Sales Order Line Item unit of measure : " + entry.getValue().getUnitMeasure());
			System.out.println("Sales Order Line Item Amount : " + entry.getValue().getAmount());
			
		}
		
	}


}