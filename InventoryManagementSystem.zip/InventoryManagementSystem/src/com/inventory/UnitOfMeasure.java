package com.inventory;



public enum UnitOfMeasure { 
	litre,
	kg,
	lb,
	ml,
	pcs,
	none;

 
 }