package com.inventory;



public class Employee {

	/**
	 * 
	 */
	public int emp_id;
	/**
	 * 
	 */
	public String department;
	/**
	 * 
	 */
	public String name;
	/**
	 * Getter of emp_id
	 */
	public int getEmp_id() {
	 	 return emp_id; 
	}
	/**
	 * Setter of emp_id
	 */
	public void setEmp_id(int emp_id) { 
		 this.emp_id = emp_id; 
	}
	/**
	 * Getter of department
	 */
	public String getDepartment() {
	 	 return department; 
	}
	/**
	 * Setter of department
	 */
	public void setDepartment(String department) { 
		 this.department = department; 
	}
	/**
	 * Getter of name
	 */
	public String getName() {
	 	 return name; 
	}
	/**
	 * Setter of name
	 */
	public void setName(String name) { 
		 this.name = name; 
	} 

}