package com.inventory;



public enum Enumeration1 { 
	EnumerationLiteral1;

 
 }