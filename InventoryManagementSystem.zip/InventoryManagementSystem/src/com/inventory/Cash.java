package com.inventory;



public class Cash extends Payment {

	/**
	 * 
	 */
	public void paymentReceipt() { 
		// TODO Auto-generated method
	 } 

}