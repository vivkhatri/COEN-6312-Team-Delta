package com.inventory;

import java.util.Date;

public abstract class Payment {

	/**
	 * 
	 */
	public int billNo;
	/**
	 * 
	 */
	public int deliveryNo;
	/**
	 * 
	 */
	public Float paymentAmount;
	/**
	 * 
	 */
	public PaymentType paymentType;
	/**
	 * 
	 */
	public Date paymentDate;
	/**
	 * Getter of billNo
	 */
	public int getBillNo() {
	 	 return billNo; 
	}
	/**
	 * Setter of billNo
	 */
	public void setBillNo(int billNo) { 
		 this.billNo = billNo; 
	}
	/**
	 * Getter of deliveryNo
	 */
	public int getDeliveryNo() {
	 	 return deliveryNo; 
	}
	/**
	 * Setter of deliveryNo
	 */
	public void setDeliveryNo(int deliveryNo) { 
		 this.deliveryNo = deliveryNo; 
	}
	/**
	 * Getter of paymentAmount
	 */
	public Float getPaymentAmount() {
	 	 return paymentAmount; 
	}
	/**
	 * Setter of paymentAmount
	 */
	public void setPaymentAmount(Float paymentAmount) { 
		 this.paymentAmount = paymentAmount; 
	}
	/**
	 * Getter of paymentType
	 */
	public PaymentType getPaymentType() {
	 	 return paymentType; 
	}
	/**
	 * Setter of paymentType
	 */
	public void setPaymentType(PaymentType paymentType) { 
		 this.paymentType = paymentType; 
	}
	/**
	 * Getter of paymentDate
	 */
	public Date getPaymentDate() {
	 	 return paymentDate; 
	}
	/**
	 * Setter of paymentDate
	 */
	public void setPaymentDate(Date paymentDate) { 
		 this.paymentDate = paymentDate; 
	}
	/**
	 * 
	 * @param success 
	 */
	public void paymentConfirmation(Boolean success) { 
		// TODO Auto-generated method
	 } 

}