package com.inventory;

import java.util.Date;
import java.util.Scanner;

public class Customer {

	/**
	 * 
	 */
	public int cust_id;
	/**
	 * 
	 */
	public String name;
	/**
	 * 
	 */
	public String address;
	/**
	 * 
	 */
	public int age;
	/**
	 * 
	 */
	public String shipping_address;
	/**
	 * 
	 */
	public Date shipping_date;

	/**
	 * Getter of cust_id
	 */
	public int getCust_id() {
		return cust_id;
	}

	/**
	 * Setter of cust_id
	 */
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

	/**
	 * Getter of name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Setter of name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Getter of address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Setter of address
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * Getter of age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * Setter of age
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * Getter of shipping_address
	 */
	public String getShipping_address() {
		return shipping_address;
	}

	/**
	 * Setter of shipping_address
	 */
	public void setShipping_address(String shipping_address) {
		this.shipping_address = shipping_address;
	}

	/**
	 * Getter of shipping_date
	 */
	public Date getShipping_date() {
		return shipping_date;
	}

	/**
	 * Setter of shipping_date
	 */
	public void setShipping_date(Date shipping_date) {
		this.shipping_date = shipping_date;
	}

	/**
	 * 
	 */
	public void makePayment() {
		// TODO Auto-generated method
	}

	/**
	 * 
	 */
	public void createCustomer() {
		Scanner cust = new Scanner(System.in);

		System.out.println("Enter the Customer Id:");
		int customer_id = Integer.parseInt(cust.nextLine());

		System.out.println("Enter the Customer Name:");
		String customer_name = cust.nextLine();

		System.out.println("Enter the Customer Address");
		String customer_address = cust.nextLine();
		int customer_age = 0;
		try {
			System.out.println("Enter the Customer Age");
			customer_age = Integer.parseInt(cust.nextLine());
		} catch (Exception e) {
			System.out.println("Error!");
		}

		if (customer_id > 0 && customer_name != "") {
			this.setCust_id(customer_id);
			this.setName(customer_name);
			this.setAddress(customer_address);
			this.setShipping_address(customer_address);
			this.setAge(customer_age);
			this.viewCustomer();
		} else {
			System.out.println("Please Enter the details Correctly");
		}
	}

	/**
	 * 
	 */
	public void viewCustomer() {
		System.out.println("Customer Id : " + this.getCust_id());
		System.out.println("Customer Name : " + this.getName());
		System.out.println("Customer Address : " + this.getAddress());
		System.out.println("Customer Age : " + this.getAge());
		System.out.println("Customer Shipping Address : " + this.getShipping_address());
	}

	/**
	 * 
	 */
	public void returnStock() {
		// TODO Auto-generated method
	}

}