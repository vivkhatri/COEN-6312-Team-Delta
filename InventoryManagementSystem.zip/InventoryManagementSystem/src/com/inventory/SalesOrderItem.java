package com.inventory;



import java.util.List;

public class SalesOrderItem {

	/**
	 * 
	 */
	public int orderNo;
	/**
	 * 
	 */
	public int orderLineItemNo;
	/**
	 * 
	 */
	public int productId;
	/**
	 * 
	 */
	public String productDescription;
	/**
	 * 
	 */
	public int quantity;
	/**
	 * 
	 */
	public UnitOfMeasure unitMeasure;
	/**
	 * 
	 */
	public Float amount;
	/**
	 * Getter of orderNo
	 */
	public int getOrderNo() {
	 	 return orderNo; 
	}
	/**
	 * Setter of orderNo
	 */
	public void setOrderNo(int orderNo) { 
		 this.orderNo = orderNo; 
	}
	/**
	 * Getter of orderLineItemNo
	 */
	public int getOrderLineItemNo() {
	 	 return orderLineItemNo; 
	}
	/**
	 * Setter of orderLineItemNo
	 */
	public void setOrderLineItemNo(int orderLineItemNo) { 
		 this.orderLineItemNo = orderLineItemNo; 
	}
	/**
	 * Getter of productId
	 */
	public int getProductId() {
	 	 return productId; 
	}
	/**
	 * Setter of productId
	 */
	public void setProductId(int productId) { 
		 this.productId = productId; 
	}
	/**
	 * Getter of productDescription
	 */
	public String getProductDescription() {
	 	 return productDescription; 
	}
	/**
	 * Setter of productDescription
	 */
	public void setProductDescription(String productDescription) { 
		 this.productDescription = productDescription; 
	}
	/**
	 * Getter of quantity
	 */
	public int getQuantity() {
	 	 return quantity; 
	}
	/**
	 * Setter of quantity
	 */
	public void setQuantity(int quantity) { 
		 this.quantity = quantity; 
	}
	/**
	 * Getter of unitMeasure
	 */
	public UnitOfMeasure getUnitMeasure() {
	 	 return unitMeasure; 
	}
	/**
	 * Setter of unitMeasure
	 */
	public void setUnitMeasure(UnitOfMeasure unitMeasure) { 
		 this.unitMeasure = unitMeasure; 
	}
	/**
	 * Getter of amount
	 */
	public Float getAmount() {
	 	 return amount; 
	}
	/**
	 * Setter of amount
	 */
	public void setAmount(Float amount) { 
		 this.amount = amount; 
	}
	/**
	 * 
	 */
	public void totalAmount() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void searchProductCode() { 
		// TODO Auto-generated method
	 } 

}