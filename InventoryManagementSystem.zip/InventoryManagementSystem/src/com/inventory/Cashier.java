package com.inventory;



public class Cashier extends Employee {

	/**
	 * 
	 */
	public int invoiceNo;
	/**
	 * 
	 */
	public Float billAmount;
	/**
	 * Getter of invoiceNo
	 */
	public int getInvoiceNo() {
	 	 return invoiceNo; 
	}
	/**
	 * Setter of invoiceNo
	 */
	public void setInvoiceNo(int invoiceNo) { 
		 this.invoiceNo = invoiceNo; 
	}
	/**
	 * Getter of billAmount
	 */
	public Float getBillAmount() {
	 	 return billAmount; 
	}
	/**
	 * Setter of billAmount
	 */
	public void setBillAmount(Float billAmount) { 
		 this.billAmount = billAmount; 
	}
	/**
	 * 
	 * @param deliveryNo 
	 */
	public void createInvoice(int deliveryNo) { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void changeInvoice() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void deleteInvoice() { 
		// TODO Auto-generated method
	 } 

}