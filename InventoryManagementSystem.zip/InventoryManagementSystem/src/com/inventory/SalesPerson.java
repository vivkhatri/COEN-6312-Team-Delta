package com.inventory;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class SalesPerson extends Employee {

	private static HashMap<Integer, Customer> customerMap = new HashMap<Integer, Customer>();
	private static HashMap<Integer, InventoryStock> inventoryMap = new HashMap<Integer, InventoryStock>();
	private static HashMap<Integer, SalesOrder> salesOrderMap = new HashMap<Integer, SalesOrder>();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int userChoice;
		int OrderNo = 0;
		Scanner input = new Scanner(System.in);
		int selectedInventoryID;
		boolean exit = false;

		while (!exit) {

			System.out.println("Please Make Your Selection");
			System.out.println("1 - Sales Order");
			System.out.println("2 - Delivery Number");
			System.out.println("3 - Inventory Manage");
			System.out.println("4 - Register Customer");
			System.out.println("5 - Quit");
			userChoice = input.nextInt();

			switch (userChoice) {
			case 1:

				System.out.println("Sales Order :: " + userChoice);
				int userSalesChoice;
				System.out.println("Select Inventory Option");
				System.out.println("1 - Crate Sales Order");
				System.out.println("2 - Change Sales Order");
				System.out.println("3 - Delete Sales Order");
				System.out.println("4 - Print Sales Order");

				userSalesChoice = input.nextInt();

				switch (userSalesChoice) {

				case 1:

					System.out.println("Create Sales Order: " + userSalesChoice);
					try {
						for (Map.Entry<Integer, Customer> entry : customerMap.entrySet()) {
							System.out.println("Customers : " + entry.getKey() +" "+ entry.getValue().getName());
						}
						System.out.println("Select Customer From Above Customer List");
						int customerId = input.nextInt();
						Customer customer = customerMap.get(customerId);
						SalesOrder salesOrder = new SalesOrder();
						salesOrder.createOrder(customer, inventoryMap);
						salesOrderMap.put(salesOrder.getOrderNo(), salesOrder);
						for (Map.Entry<Integer, SalesOrder> entry : salesOrderMap.entrySet()) {
							entry.getValue().getOrderAmount();
						}
					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					break;

				case 2:
					System.out.println("Change Sales Order: " + userSalesChoice);
					try {
						
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case 3:
					System.out.println("Delete Sales Order: " + userSalesChoice);
					System.out.println("Select Stock Number to be Removed");
					for (Map.Entry<Integer, SalesOrder> entry : salesOrderMap.entrySet()) {
						System.out.println(entry.getKey());
					}
					int selectedOrderNumber = input.nextInt();
					salesOrderMap.remove(selectedOrderNumber);
					break;
				case 4:
					System.out.println("View Sales Order: " + userSalesChoice);
					
					for (Map.Entry<Integer, SalesOrder> entry : salesOrderMap.entrySet()) {

						entry.getValue().viewOrder();

					}
					break;
				}
				break;

			case 2:

				System.out.println("Order Delivery :: " + userChoice);
				System.out.println("Sales Order No :: " + OrderNo);

				break;
			case 3:

				System.out.println("Manage Inventory" + userChoice);
				int userInventoryChoice;
				System.out.println("Select Inventory Option");
				System.out.println("1 - Add New Stock");
				System.out.println("2 - Update Existing Stock");
				System.out.println("3 - Remove Stock");
				System.out.println("4 - View Stock");

				userInventoryChoice = input.nextInt();

				switch (userInventoryChoice) {

				case 1:
					System.out.println("Add Inventory: " + userInventoryChoice);
					try {
						insertInventory();

					} catch (ParseException e) {
						// TODO Aut1o-generated catch block
						e.printStackTrace();
					}
					break;
				case 2:
					System.out.println("Update Inventory: " + userInventoryChoice);
					// Print all Inventory IDs:
					System.out.println("Select from Following Inventory Ids");
					for (Map.Entry<Integer, InventoryStock> entry : inventoryMap.entrySet()) {
						System.out.println("Inventory ID " + entry.getKey());
					}
					selectedInventoryID = input.nextInt();
					try {
						inventoryMap.get(selectedInventoryID).changeDetails();
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case 3:
					System.out.println("Remove Inventory: " + userInventoryChoice);
					System.out.println("Select from Following Inventory Ids");
					for (Map.Entry<Integer, InventoryStock> entry : inventoryMap.entrySet()) {
						System.out.println("Inventory ID " + entry.getKey());
					}
					selectedInventoryID = input.nextInt();
					inventoryMap.remove(selectedInventoryID);
					break;
				case 4:
					System.out.println("View Inventory: " + userInventoryChoice);
					System.out.println("Select from Following Inventory Ids");
					for (Map.Entry<Integer, InventoryStock> entry : inventoryMap.entrySet()) {
						entry.getValue().listStock();
					}
					break;
				}
				break;

			case 4:
				System.out.print("Customer Register:");
				Customer customer = new Customer();
				customer.createCustomer();
				customerMap.put(customer.getCust_id(), customer);
				break;

			case 5:
				exit = true;
				System.out.println("End Process" + userChoice);

			}
		}

	}

	private static void insertInventory() throws ParseException {
		InventoryStock inventory = new InventoryStock();
		inventory.addStock();
		int prodId = inventory.getProductId();
		inventoryMap.put(prodId, inventory);
		System.out.println("Stock Added Successfully");
	}

	/**
	 * 
	 */
	public void orderRequest() {
		// TODO Auto-generated method
	}

}