package com.inventory;

import java.util.Date;

public class OrderDelivery {

	/**
	 * 
	 */
	public int deliveryNo;
	/**
	 * 
	 */
	public Date deliveryDate;
	/**
	 * 
	 */
	public int cust_id;
	/**
	 * 
	 */
	public int emp_id;
	/**
	 * 
	 */
	public Float deliveryAmount;
	/**
	 * 
	 */
	public String shipping_address;
	/**
	 * 
	 */
	public Date shipping_date;
	/**
	 * 
	 */
	public DeliveryStatus deliveryStatus;
	/**
	 * 
	 */
	public int orderNo;
	/**
	 * Getter of deliveryNo
	 */
	public int getDeliveryNo() {
	 	 return deliveryNo; 
	}
	/**
	 * Setter of deliveryNo
	 */
	public void setDeliveryNo(int deliveryNo) { 
		 this.deliveryNo = deliveryNo; 
	}
	/**
	 * Getter of deliveryDate
	 */
	public Date getDeliveryDate() {
	 	 return deliveryDate; 
	}
	/**
	 * Setter of deliveryDate
	 */
	public void setDeliveryDate(Date deliveryDate) { 
		 this.deliveryDate = deliveryDate; 
	}
	/**
	 * Getter of cust_id
	 */
	public int getCust_id() {
	 	 return cust_id; 
	}
	/**
	 * Setter of cust_id
	 */
	public void setCust_id(int cust_id) { 
		 this.cust_id = cust_id; 
	}
	/**
	 * Getter of emp_id
	 */
	public int getEmp_id() {
	 	 return emp_id; 
	}
	/**
	 * Setter of emp_id
	 */
	public void setEmp_id(int emp_id) { 
		 this.emp_id = emp_id; 
	}
	/**
	 * Getter of deliveryAmount
	 */
	public Float getDeliveryAmount() {
	 	 return deliveryAmount; 
	}
	/**
	 * Setter of deliveryAmount
	 */
	public void setDeliveryAmount(Float deliveryAmount) { 
		 this.deliveryAmount = deliveryAmount; 
	}
	/**
	 * Getter of shipping_address
	 */
	public String getShipping_address() {
	 	 return shipping_address; 
	}
	/**
	 * Setter of shipping_address
	 */
	public void setShipping_address(String shipping_address) { 
		 this.shipping_address = shipping_address; 
	}
	/**
	 * Getter of shipping_date
	 */
	public Date getShipping_date() {
	 	 return shipping_date; 
	}
	/**
	 * Setter of shipping_date
	 */
	public void setShipping_date(Date shipping_date) { 
		 this.shipping_date = shipping_date; 
	}
	/**
	 * Getter of deliveryStatus
	 */
	public DeliveryStatus getDeliveryStatus() {
	 	 return deliveryStatus; 
	}
	/**
	 * Setter of deliveryStatus
	 */
	public void setDeliveryStatus(DeliveryStatus deliveryStatus) { 
		 this.deliveryStatus = deliveryStatus; 
	}
	/**
	 * Getter of orderNo
	 */
	public int getOrderNo() {
	 	 return orderNo; 
	}
	/**
	 * Setter of orderNo
	 */
	public void setOrderNo(int orderNo) { 
		 this.orderNo = orderNo; 
	}
	/**
	 * 
	 */
	public void printDelivery() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void calculateTax() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void totalAmount() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 * @param orderNo 
	 */
	public void createDelivery(int orderNo) { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void changeDelivery() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void cancelDelivery() { 
		// TODO Auto-generated method
	 } 

}